package com.chatapp.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")   // ✅ FIX HERE
public class User {

    @Id
    @GeneratedValue
    private Long id;

    private String username;
    private String password;
    private String status;

    // getters & setters
    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }

    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }

    public void setPassword(String password) { this.password = password; }

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }
}